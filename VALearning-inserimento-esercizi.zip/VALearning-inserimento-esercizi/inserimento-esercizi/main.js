const statoAttuale = STATUS.LOGGED_IN_INSEGNANTE;

window.addEventListener("DOMContentLoaded", () => {
  const formEsercizio = document.getElementById("form-crea-esercizio");
  const formContainer = formEsercizio.querySelector(".creazione-container");
  const formTipologiaEsercizio = document.getElementById("tipologia-esercizio");

  formEsercizio.addEventListener("submit", (e) => {
    e.preventDefault();
    gestisciSubmit(formTipologiaEsercizio.value);
  });

  formTipologiaEsercizio.addEventListener("change", (e) => {
    formContainer.innerHTML =
      TIPOLOGIA_ESERCIZIO_HTML_TEMPLATE[e.target.value] ??
      "Errore! Ricaricare la pagina";

      console.log(e.target.value)
      console.log(e.target)

    switch (e.target.value) {
      case TIPO_ESERCIZI.VERO_FALSO:
        break;
      case TIPO_ESERCIZI.TESTO_BUCATO:
        gestisciTestoBucato();
        break;
      case TIPO_ESERCIZI.RISPOSTE_MULTIPLE:
        gestisciRisposteMultiple();
        break;
      case TIPO_ESERCIZI.WRITING_ONE:
        gestisciWritingOne();
        break;
      case TIPO_ESERCIZI.REPHRASING:
        gestisciRephrasing();
        break;
        case TIPO_ESERCIZI.WRITING_TWO:
          gestisciWritingTwo();
        break;
        case TIPO_ESERCIZI.OPEN_CLOZE:
          gestisciOpenCloze();
        break;
        case TIPO_ESERCIZI.WORD_FORMATION:
          gestisciWordFormation();
        break;
    }
  });

  suggerimentoArgomento();

  document.getElementById("btn-publica").textContent =
    statoAttuale === STATUS.LOGGED_IN_INSEGNANTE ? "Pubblica" : "Proponi";

  document
    .querySelector('#form-crea-esercizio button[type="reset"]')
    .addEventListener("click", () => {
      document
        .querySelectorAll("#form-crea-esercizio .badge")
        .forEach((badge) => badge.remove());
      formTipologiaEsercizio.selectedIndex = 0;
      formTipologiaEsercizio.dispatchEvent(new Event("change"));
    });

  document.getElementById("btn-preview").addEventListener("click", () => {
    alert(
      "Preview dell'esercizio: implementazione da parte del gruppo che fa la visualizzazione degli esercizi"
    );
  });
});

function suggerimentoArgomento(
  textInput = document.getElementById("argomento-esercizio"),
  btnAggiungi = document.querySelector("#argomento-esercizio + button"),
  boxArgomenti = document.getElementById("box-argomenti"),
  suggerimento = document.querySelector(".setting-container .suggerimento")
) {
  const argomenti = ARGOMENTI.map((obj) => obj.argomento).toSorted();
  let parolaInFocus = false;
  let btnCliccabile = true;

  textInput.oninput = (e) => {
    suggerimento.innerHTML = "";
    let parola = e.target.value;
    if (parola.length === 0) {
      parolaInFocus = false;
      return;
    }

    const parolaSuggerita = cercaParola(argomenti, parola);
    if (parolaSuggerita === null) {
      parolaInFocus = false;
      return;
    }

    e.target.value = parolaSuggerita.substring(0, parola.length);
    suggerimento.innerHTML = parolaSuggerita;
    parolaInFocus = true;
  };

  textInput.onkeydown = (e) => {
    if (e.key !== "Enter" && e.key !== "Tab") return;
    if (parolaInFocus) textInput.value = suggerimento.textContent;
  };

  btnAggiungi.onclick = () => {
    if (!btnCliccabile) return;
    if (parolaInFocus) {
      boxArgomenti.append(nuovoBadgeArgomento(suggerimento.textContent));
      textInput.value = "";
      suggerimento.textContent = "";
      return;
    }
    btnCliccabile = false;
    const altBdColor = textInput.style.borderColor;
    textInput.style.borderColor = "var(--bs-red)";
    setTimeout(() => {
      textInput.style.borderColor = altBdColor;
      btnCliccabile = true;
    }, 800);
  };
}

function gestisciWritingTwo(){
  let writingTwoTextBox = document.querySelector("#writingTwo-textBox");
  let opzioniWritingTwo = document.querySelector(".opzioniWritingTwo");
  let btnNuovaDomanda = document.querySelector("#writingTwo-nuovaOpzione");
  let btnAggiungiGap = document.querySelector("#writingTwo-aggiungiGap");
  let btnRimuoviDomanda = document.querySelector("#writingTwo-rimuoviOpzione");
  let contDomande = 1;

  btnNuovaDomanda.onclick = ()=>{
    opzioniWritingTwo.innerHTML+= `<div class="fraseWritingTwo">Frase ${contDomande}<br><input type="text" class="form-control txtWritingTwo" aria-label="Text input with radio button"></div>`
    contDomande++;
  }

  btnAggiungiGap.onclick = () => {
    const box = document.querySelectorAll(".txtWritingTwo");
    let selectHTML = `<select class="form-select-sm" aria-label="Default select example">`;
    
    for (let i = 0; i < box.length; i++) {
        selectHTML += `<option value="${i+1}">${box[i].value}</option>`;
    }

    selectHTML += `</select>`;

    writingTwoTextBox.innerHTML += selectHTML;
};


  btnRimuoviDomanda.onclick = ()=>{
      if(contDomande==1) return;
      const box = document.querySelectorAll(".fraseWritingTwo");
      box[box.length - 1].remove();
      contDomande--;
  }

}

function gestisciOpenCloze(){
    let idDomanda = 0;
    let openClozeTextBox = document.querySelector("#openCloze-textBox");
    let btnNuovaDomanda = document.querySelector("#openCloze-nuovaOpzione");
    let btnRimuoviDomanda = document.querySelector("#openCloze-rimuoviOpzione");

    btnNuovaDomanda.onclick = ()=>{
      openClozeTextBox.innerHTML+= `<input type="text" class="form-control-sm txtOpenCloze" id="openClozeDomanda${idDomanda}" >`
      idDomanda++;
    }

    btnRimuoviDomanda.onclick = () =>{
      const box = document.querySelectorAll(".txtOpenCloze");
      box[box.length - 1].remove();
      idDomanda--;
    }
}

function gestisciWordFormation(){
  let idDomanda = 0;
  let wordFormationTextBox = document.querySelector("#wordFormation-textBox");
  let btnNuovaDomanda = document.querySelector("#wordFormation-nuovaOpzione");
  let btnRimuoviDomanda = document.querySelector("#wordFormation-rimuoviOpzione");
  let divParoleBase = document.querySelector(".paroleBase");

  btnNuovaDomanda.onclick = ()=>{
    wordFormationTextBox.innerHTML+= `<input type="text" class="form-control-sm txtWordFormation" id="openClozeDomanda${idDomanda}" >`
    idDomanda++;
    divParoleBase.innerHTML += `<div class="txtParolaBase"><h6>Parola Base risposta ${idDomanda}:</h6><input type="text" class="form-control" id="openClozeDomanda${idDomanda}"</div>`
  }

  btnRimuoviDomanda.onclick = () =>{
    const box = document.querySelectorAll(".txtWordFormation");
    const box2 = document.querySelectorAll(".txtParolaBase");
    box[box.length - 1].remove();
    box2[box.length - 1].remove();
    idDomanda--;
  }
}

function gestisciWritingOne(){
    let divDomande = document.querySelector(".domandeWritingOne");
    let btnNuovaDomanda = document.querySelector("#writingOne-nuovaDomanda");
    let btnRimuoviDomanda = document.querySelector("#writingOne-rimuoviDomanda");

    let contDomande = 1;
    btnNuovaDomanda.onclick = ()=>{
        if(contDomande>=8) return;
        contDomande++;
        divDomande.innerHTML += `<section class="domandaWritingOneBox">
        <label for="veroFalso-domanda" class="mb-1">Domanda:</label>
        <input type="text" class="form-control" id="veroFalso-domanda"/>
          <div class="input-group my-2">
            <div class="input-group-text">
              <input class="form-check-input mt-0" type="radio" name="nuovaGap-opzione${contDomande}" checked="checked">
            </div>
            <input type="text" class="form-control" aria-label="Text input with radio button"
              placeholder="Opzione 1">
          </div>
          <div class="input-group my-2">
            <div class="input-group-text">
              <input class="form-check-input mt-0" type="radio" name="nuovaGap-opzione${contDomande}">
            </div>
            <input type="text" class="form-control" aria-label="Text input with radio button"
              placeholder="Opzione 2">
          </div>
          <div class="input-group my-2">
            <div class="input-group-text">
              <input class="form-check-input mt-0" type="radio" name="nuovaGap-opzione${contDomande}">
            </div>
            <input type="text" class="form-control" aria-label="Text input with radio button"
              placeholder="Opzione 3">
          </div>
          <div class="input-group my-2">
            <div class="input-group-text">
              <input class="form-check-input mt-0" type="radio" name="nuovaGap-opzione${contDomande}">
            </div>
            <input type="text" class="form-control" aria-label="Text input with radio button"
              placeholder="Opzione 4">
          </div>
        </div>
        </section>`
    }

    btnRimuoviDomanda.onclick = ()=>{
      if(contDomande==1) return;
        contDomande--;
        const box = document.querySelectorAll(".domandaWritingOneBox");
        box[box.length - 1].remove();

    }
}

function gestisciRephrasing(){
  let divDomande = document.querySelector("#rephrasing-container");
  let btnRimuoviDomanda = document.querySelector("#rephrasing-rimuoviDomanda")
    let btnNuovaDomanda = document.querySelector("#rephrasing-nuovaDomanda")
  let contOpzioni = 1;
    btnNuovaDomanda.onclick = ()=>{
      if(contOpzioni >=6) return;
      contOpzioni++;
      divDomande.innerHTML += `<br><br> <section class="domandaRephrasing">
      <label for="rephrasing-domanda" class="form-label">Domanda:</label>
        <input type="text" class="form-control" id="rephrasing-domanda">
      <br><label for="rephrasing-parolaChiave" class="form-label">PAROLA CHIAVE:</label>
        <br><input type="text" class="form-control-sm" id="rephrasing-parolaChiave">
        <br> <br> <label for="rephrasing-risposta" class="form-label">Risposta:</label>
       <input type="text" class="form-control" id="rephrasing-risposta">
    <div class="btn-box mt-3">
    </section>`
    }

    btnRimuoviDomanda.onclick = ()=>{
      if(contDomande==1) return;
        contDomande--;
        const box = document.querySelectorAll(".domandaRephrasing");
        box[box.length - 1].remove();

    }
}

function gestisciVeroFalso() {}

function gestisciTestoBucato() {
  const btnNuovaOpzione = document.getElementById(
    "risposteMultiple-nuovaOpzione"
  );
  const btnRimuoviOpzione = document.getElementById(
    "risposteMultiple-rimuoviOpzione"
  );
  const btnAggiungiGap = document.getElementById(
    "risposteMultiple-aggiungiGap"
  );

  let contOpzioni = 2;

  console.log(btnNuovaOpzione, btnRimuoviOpzione);

  btnNuovaOpzione.onclick = () => {
    if (contOpzioni >= 4) return;
    contOpzioni += 1;
    document.querySelector(".opzioni").append(nuovoOpzioneNuovaGap());
  };

  btnRimuoviOpzione.onclick = () => {
    if (contOpzioni <= 2) return;
    contOpzioni -= 1;
    const box = document.querySelector(".opzioni");
    box.removeChild(box.lastChild);
  };

  btnAggiungiGap.onclick = () => {
    let err = false;
    for (const opzione of document.querySelectorAll(".opzioni .input-group")) {
      err |= opzione.querySelector('input[type="text"]').value.trim() === "";
    }

    if (err) {
      const alert = nuovoAlert(
        false,
        "<strong>Attenzione!</strong> Inserire tutte le opzioni"
      );
      document.body.prepend(alert);
      setTimeout(() => alert.querySelector("button").click(), 2500);
    } else {
      const box = document.getElementById("testoBucato-textBox");

      const alternative = [];
      let rispostaCorretta;

      for (const opzione of document.querySelectorAll(
        ".opzioni .input-group"
      )) {
        const input = opzione.querySelector('input[type="radio"]');
        if (input.checked)
          rispostaCorretta = opzione
            .querySelector('input[type="text"]')
            .value.trim();
        else
          alternative.push(
            opzione.querySelector('input[type="text"]').value.trim()
          );
      }

      box.append(nuovoDropdown(rispostaCorretta, alternative));
      box.innerHTML += "&nbsp;";
      setEndOfContenteditable(box);

      // pulizia
      document.querySelector(".opzioni").innerHTML = `
        <div class="input-group my-2">
          <div class="input-group-text">
            <input class="form-check-input mt-0" type="radio" name="nuovaGap-opzione" checked="checked">
          </div>
          <input type="text" class="form-control" aria-label="Text input with radio button"
            placeholder="Opzione 1">
        </div>
        <div class="input-group my-2">
          <div class="input-group-text">
            <input class="form-check-input mt-0" type="radio" name="nuovaGap-opzione">
          </div>
          <input type="text" class="form-control" aria-label="Text input with radio button"
            placeholder="Opzione 2">
        </div>
      `;
    }
  };
}
function setEndOfContenteditable(contentEditableElement) {
  var range, selection;
  if (document.createRange) {
    //Firefox, Chrome, Opera, Safari, IE 9+
    range = document.createRange(); //Create a range (a range is a like the selection but invisible)
    range.selectNodeContents(contentEditableElement); //Select the entire contents of the element with the range
    range.collapse(false); //collapse the range to the end point. false means collapse to end rather than the start
    selection = window.getSelection(); //get the selection object (allows you to change selection)
    selection.removeAllRanges(); //remove any selections already made
    selection.addRange(range); //make the range you have just created the visible selection
  } else if (document.selection) {
    //IE 8 and lower
    range = document.body.createTextRange(); //Create a range (a range is a like the selection but invisible)
    range.moveToElementText(contentEditableElement); //Select the entire contents of the element with the range
    range.collapse(false); //collapse the range to the end point. false means collapse to end rather than the start
    range.select(); //Select the range (make it the visible selection
  }
}

function gestisciRisposteMultiple() {
  const btnNuovaOpzione = document.getElementById(
    "risposteMultiple-nuovaOpzione"
  );

  const btnrimuoviOpzione = document.getElementById(
    "risposteMultiple-rimuoviOpzione"
  );

  const opzioniBox = document.querySelector(".creazione-container .opzioni");

  let contOpzioni = 3;

  btnNuovaOpzione.onclick = () => {
    if (contOpzioni > 7) {
      return;
    }
    contOpzioni += 1;
    opzioniBox.append(nuovoOpzioneRisposteMultiple());
  };

  btnrimuoviOpzione.onclick = () => {
    if (contOpzioni < 4) {
      return;
    }
    contOpzioni -= 1;
    opzioniBox.removeChild(opzioniBox.lastChild);
  };
}

function gestisciSubmit(tipologiaEsercizio) {
  let json;
  const elementiMancanti = [];

  // if (document.querySelector("#box-argomenti").childElementCount === 0) {
  //   elementiMancanti.push("Argomento mancante");
  // }

  switch (tipologiaEsercizio) {

    case TIPO_ESERCIZI.OPEN_CLOZE:
      let o = document.querySelector("#openCloze-textBox")
      const htmlString = o.innerHTML
      let regex = /<[^>]*>/g;
      const tagHTML = htmlString.match(regex);
      json = {
        tipo: "openCloze",
        text : o.innerHTML,
        onlyTags : tagHTML,
        onlyText : o.textContent
      }
      console.log(json);
  
      break;
    case TIPO_ESERCIZI.TESTO_BUCATO:
      if (document.getElementById("nome-esercizio").value.trim() === "") {
        elementiMancanti.push("Nome esercizio mancante");
      }
      if (!document.querySelector("#testoBucato-textBox > .dropdown")) {
        elementiMancanti.push("Inserisci almeno una gap!");
      }
      /*
      const ul = document.getElementById('ul-id');
const lis = ul.getElementsByTagName('li');

for (let i = 0; i < lis.length; i++) {
    const li = lis[i];
    // Utilizza 'li' qui per accedere all'elemento <li> corrente
    console.log(`Indice: ${i}, Contenuto: ${li.textContent}`);
}

      */
      // let obj = {};
      // let objOp = {};
      // let corrette = document.querySelectorAll(".dropdown-toggle")
      // let opzioni = document.querySelectorAll(".dropdown-menu")
      // for(let i=0; i<corrette.length; i++)
      //   obj[i+1] = corrette[i].textContent.trim();
      // for(let i=0; i<opzioni.length; i++)
      //   objOp[0] = corrette[i].textContent.trim();
      //   objOp[i+1] = opzioni[i].innerText;

      // json = {
      //   tipo: "testoBucato",
      //   text: document.querySelector("#testoBucato-textBox").textContent.trim(),
      //   corrects: obj,
      //   options: objOp
      // }
      // console.log(json)
      break;
    case TIPO_ESERCIZI.VERO_FALSO:
      if (document.getElementById("veroFalso-domanda").value.trim() === "") {
        elementiMancanti.push("Domanda del vero e falso mancante");
      }
      json = {
        tipo: "veroFalso",
        domanda : document.getElementById("veroFalso-domanda").value,
        risposta : !(document.getElementById("veroFalso-falso").checked),
        correzione : document.getElementById("veroFalso-correzione").value
      }
      console.log(json)
      break;
    case TIPO_ESERCIZI.REPHRASING:
      if (document.getElementById("nome-esercizio").value.trim() === "") {
        elementiMancanti.push("Nome esercizio mancante");
      }
      if (!document.querySelector("#testoBucato-textBox > .dropdown")) {
        elementiMancanti.push("Inserisci almeno una gap!");
      }
      break;
    case TIPO_ESERCIZI.RISPOSTE_MULTIPLE:
      if (
        document.getElementById("risposteMultiple-domanda").value.trim() === ""
      ) {
        elementiMancanti.push("Domanda dell'esercizio mancante");
      }

      for (const inputGroup of document.querySelectorAll(
        ".creazione-container .opzioni > .input-group"
      )) {
        console.log(inputGroup);
        if (
          inputGroup.querySelector('input[type="text"]').value.trim() === ""
        ) {
          elementiMancanti.push("Testo opzioni mancante");
          break;
        }
      }
      break;

      case TIPO_ESERCIZI.WORD_FORMATION:
      if (document.getElementById("nome-esercizio").value.trim() === "") {
        elementiMancanti.push("Nome esercizio mancante");
      }
      if (!document.querySelector("#testoBucato-textBox > .dropdown")) {
        elementiMancanti.push("Inserisci almeno una gap!");
      }
      break;

      case TIPO_ESERCIZI.WRITING_ONE:
      if (document.getElementById("nome-esercizio").value.trim() === "") {
        elementiMancanti.push("Nome esercizio mancante");
      }
      if (!document.querySelector("#testoBucato-textBox > .dropdown")) {
        elementiMancanti.push("Inserisci almeno una gap!");
      }
      break;
      
      case TIPO_ESERCIZI.WRITING_TWO:
      if (document.getElementById("nome-esercizio").value.trim() === "") {
        elementiMancanti.push("Nome esercizio mancante");
      }
      if (!document.querySelector("#testoBucato-textBox > .dropdown")) {
        elementiMancanti.push("Inserisci almeno una gap!");
      }
      break;
  }

  if (elementiMancanti.length === 0) {
    var alert = nuovoAlert(
      true,
      "<strong>Esercizio creato con success!</strong>"
    );

    // creazione oggetto, in base al tipo es diversi attributi.

    const esercizio = {};

    esercizio.livello = document.getElementById("difficoltà-esercizio").value;

    const nomeverfalso = document.getElementById("nome-esercizio").value.trim();
    if (nomeverfalso === "") {
      esercizio.nome = null;
    } else {
      esercizio.nome = nomeverfalso;
    }

    esercizio.argomenti = [];
    const argomento_box = document.querySelectorAll("#box-argomenti > span");
    for (const span of argomento_box) {
      esercizio.argomenti.push(span.textContent);
    }
    esercizio.tipologia = tipologiaEsercizio;

    switch (tipologiaEsercizio) {
      case TIPO_ESERCIZI.VERO_FALSO:
        esercizio.domanda = document
          .getElementById("veroFalso-domanda")
          .value.trim();
        esercizio.risposta = document.getElementById("veroFalso-vero").checked;

        const correzione = document
          .getElementById("veroFalso-correzione")
          .textContent.trim();
        if (correzione === "") {
          esercizio.correzione = null;
        } else {
          esercizio.correzione = correzione;
        }

        break;
      case TIPO_ESERCIZI.TESTO_BUCATO:
        esercizio.testo = document.getElementById(
          "testoBucato-textBox"
        ).textContent;
        break;

      case TIPO_ESERCIZI.RISPOSTE_MULTIPLE:
        esercizio.domanda = document
          .getElementById("risposteMultiple-domanda")
          .value.trim();
        esercizio.opzioni = [];
        document
          .querySelectorAll(".opzioni .input-group")
          .forEach((opzione) => {
            if (opzione.querySelector('input[type="radio"]').checked) {
              esercizio.opzioni = [
                opzione.querySelector('input[type="text"]').value,
                ...esercizio.opzioni,
              ];
            } else {
              esercizio.opzioni.push(
                opzione.querySelector('input[type="text"]').value
              );
            }
          });
        break;
    }

    // aggiungo esercizio all'array 
    esercizi_creati.push(esercizio);
  } else {
    let messaggio = "";
    for (const errore of elementiMancanti) messaggio += `- ${errore} <br>`;
    var alert = nuovoAlert(
      false,
      "<strong>Attenzione!</strong><br>" + messaggio
    );
  }

  document.body.prepend(alert);
  setTimeout(() => alert.querySelector("button").click(), 2500);
}
